package pageActions;


import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;


import webDriver.Driver;

import testData.Xls_Reader;

public class PageActions {

	public final  String excelWorkBook="TestData.xlsx";
	String TC_sheet="TestCases";
	String TD_sheet="TestData";
	public static Xls_Reader xls;
	String billNumber="";



	public final  String col_TestCaseID="TCID";
	public String col_UserName="UserName";
	public String col_Password="Password";
	public String col_Vendor="Vendor";
	public String col_Bill="Bill";
	public String col_Description="Description";	
	public String col_Account="Account";	
	public String col_LineDescription="LineDescription";
	public String col_LineTotal="LineTotal";
	public String col_Customer="Customer";
	public String col_Class="Class";
	public String col_PageTitle="PageTitle";


	public PageActions() {
		String path=System.getProperty("user.dir")+"//TestDataFiles//"+excelWorkBook;
		xls = new Xls_Reader(path);	
	}

	public String getURL(){
		return xls.getCellData(TD_sheet, "URL", 2);
	}

	public String getBrowser(){
		return xls.getCellData(TD_sheet, "Browser", 2);
	}

	public Map<String,String> getTestData(String testCaseID){
		Map<String,String>testdata=new HashMap<String,String>();
		int rowNum=xls.getRowNum(TD_sheet, testCaseID);
		testdata.put(col_UserName,xls.getCellData(TD_sheet, testCaseID, col_UserName, rowNum));
		testdata.put(col_Password,xls.getCellData(TD_sheet, testCaseID, col_Password, rowNum));
		testdata.put(col_Vendor,xls.getCellData(TD_sheet, testCaseID, col_Vendor, rowNum));
		testdata.put(col_Bill,xls.getCellData(TD_sheet, testCaseID, col_Bill, rowNum));
		testdata.put(col_Description, xls.getCellData(TD_sheet, testCaseID, col_Description, rowNum));
		testdata.put(col_Account, xls.getCellData(TD_sheet, testCaseID, col_Account, rowNum));
		testdata.put(col_LineDescription, xls.getCellData(TD_sheet, testCaseID, col_LineDescription, rowNum));
		testdata.put(col_LineTotal, xls.getCellData(TD_sheet, testCaseID, col_LineTotal, rowNum));
		testdata.put(col_Customer, xls.getCellData(TD_sheet, testCaseID, col_Customer, rowNum));
		testdata.put(col_Class, xls.getCellData(TD_sheet, testCaseID, col_Class, rowNum));
		testdata.put(col_PageTitle, xls.getCellData(TD_sheet, testCaseID, col_PageTitle, rowNum));
		return testdata;
	}

	public void login(String testCaseID) throws Exception{
		Map<String,String>data=getTestData(testCaseID);
		Driver.sendKey(By.id("emailId"), data.get(col_UserName));
		Driver.sendKey(By.id("password"), data.get(col_Password));
		Driver.click(By.id("loginSubmit"));
		Driver.wait(5);
	}

	/**Get Time in Milliseconds */
	public  String getTime_Milliseconds()
	{
		Date date= new Date();
		long time = date.getTime();
		String str = String.valueOf(time);
		String text=str.substring(str.length() - 8);
		return text;
	}

	public  String getRandomNumber(){
		Random rand = new Random();
		int n = rand.nextInt(999999999);	
		n += 1;
		return ""+n;		
	}
}
