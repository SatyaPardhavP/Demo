package testScripts;

import java.sql.SQLException;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import com.relevantcodes.extentreports.LogStatus;

import base.SuiteBase;
import base.TestLink;
import pageActions.PageActions;
import webDriver.Driver;

public class DemoTest extends SuiteBase {

	PageActions obj_pa;
	String ClassName;

	@BeforeClass
	public void open(){
		obj_pa=new PageActions();
		Driver.open(obj_pa.getBrowser(),obj_pa.getURL());
		ClassName = this.getClass().getSimpleName();
	}

	@Test
	public void TC_00_01() throws Exception {		
		String testCaseID=getMethodName();
		Map<String,String> td=obj_pa.getTestData(testCaseID);
		boolean isSkip=skip_Test(testCaseID);		
		String result=null;
		String execution_notes = null;
		try {
			startTest(testCaseID,ClassName);
			obj_pa.login(testCaseID);
			
			String actMesg=Driver.getPageTitle();
			System.out.println("Actual :"+actMesg);			
			String expMsg = td.get(obj_pa.col_PageTitle);			
			if(actMesg.contentEquals(expMsg)){
				execution_notes="Page title is matched successfully";
				tryBlock(testCaseID, execution_notes);				
			}
			else{
				throw new Exception("Success message is not matched");	
			}
		} catch (Exception e) {
			if(isSkip!=true){				
				execution_notes=e.getMessage();
				catchBlock(execution_notes, testCaseID);		
			}
			throw e;
		}		
	}	

	@AfterClass
	public void close(){
		Driver.getWD().close();
	}

}
