package base;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class MailSetup {
	
	public static String systemCurrentDate(){
		String sysDate=new SimpleDateFormat("MM-dd-yyyy").format(Calendar.getInstance().getTime());
		return sysDate;	
	}
	
	public static void SendEmail() throws Exception
	{

		/* Variables deceleration */

		final String username = "spamulapati@xtglobal.com";

		final String password = "!X3n0@$1234;!";
		String smtphost = "smtp.1and1.com";
		String smtpport = "25";
		String fromadd = "spamulapati@xtglobal.com";
		String toadd = "spamulapati@xtglobal.com";
		String tocc = "spamulapati@xtglobal.com";		
		String subject = "Test Automation Status";
		String atattachementpath = System.getProperty("user.dir")+"//Report//TestReport.html";
		String formattedDate=systemCurrentDate();
		String reportName = "Test_Report_"+formattedDate;
		String islocal ="0"; 
		String messagebody = "Please find the attached automation testing results.";


		Properties props = new Properties();
		if (islocal.contentEquals("0"))
		{
			props.put("mail.smtp.auth", false);

		}
		else
		{
			props.put("mail.smtp.auth", "true");
		}

		props.put("mail.smtp.host", smtphost);
		props.put("mail.smtp.port", smtpport);
		props.put("mail.smtp.auth", "true"); //enable authentication
		//props.put("mail.smtp.starttls.enable", "true"); //enable STARTTLS
		props.put("mail.smtp.starttls.enable", "mail.smtp.starttls.enable"); //enable STARTTLS
		//props.put("mail.smtp.ssl.enable", "true"); //enable STARTTLS



		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});
		//	Session session = Session.getDefaultInstance(props, null);

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromadd));

			// to send mail to Main user   
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(toadd));

			//to send mail to cc users
			message.setRecipients(Message.RecipientType.CC,
					InternetAddress.parse(tocc));

			// to send mail to bcc users

			/*  message.setRecipients(Message.RecipientType.BCC,
                InternetAddress.parse(tobcc)); */

			message.setSubject(subject+"_"+formattedDate);
			message.setText("PFA");

			// to add all the boby to mail
			Multipart multipart = new MimeMultipart();

			//to add attachement1 - XSLT Report
			MimeBodyPart messageBodyPart = new MimeBodyPart();
			DataSource source = new FileDataSource(atattachementpath);
			messageBodyPart.setDataHandler(new DataHandler(source));
			messageBodyPart.setFileName(reportName);



			//to add message body
			MimeBodyPart messageBodyPartCon1 = new MimeBodyPart();
			messageBodyPartCon1.setContent("Hi All,<br> <br>"  + messagebody + "<br> <br> <br>"
					+ "Regards, <br>"
					+ "QA Team.", "text/html");

			//to add all the parts to mail
			multipart.addBodyPart(messageBodyPart);		
			multipart.addBodyPart(messageBodyPartCon1);


			message.setContent(multipart);

			System.out.println("Sending the mail to TO configured users " + toadd);
			System.out.println("Sending the mail to CC configured users " + tocc);
			//System.out.println("Sending the mail to BCC configured users " + tobcc);

			Transport transport = session.getTransport("smtp");

			transport.connect(smtphost, username, password);

			Transport.send(message);

			System.out.println("Mail has sent to the user/users with the attachments");

		} 

		catch (MessagingException e) 
		{

			e.printStackTrace();

		}

	}

	public static void main(String[] args) throws Exception
	{
		//MailSetup s = new MailSetup();
		SendEmail();
	}



}
