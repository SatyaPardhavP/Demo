package base;

import java.awt.Desktop;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import org.testng.annotations.BeforeSuite;
import org.apache.log4j.xml.DOMConfigurator;
import org.testng.SkipException;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Parameters;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;
import testData.Xls_Reader;
import webDriver.Driver;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;
import pageActions.PageActions;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class SuiteBase {
	public static ExtentTest test;
	public static ExtentReports report;
	String workingDir;
	public static ATUTestRecorder recorder;

	@BeforeSuite
	//@Parameters({"Browser"})
	public void myTest() throws ATUTestRecorderException {
		workingDir = System.getProperty("user.dir");
		report = new ExtentReports(workingDir+"\\Report\\TestReport.html");
		//Action.report = new ExtentReports(System.getProperty("user.dir")+"\\TestReport.html");
		report.loadConfig(new File(workingDir+"/ConfigFiles/extent-config.xml"));
		Map<String,String> sysInfo = new HashMap<String,String>();
		sysInfo.put("Environment", "QA");
		sysInfo.put("Browser Name", "Chrome");
		report.addSystemInfo(sysInfo);
		DOMConfigurator.configure(workingDir+"\\ConfigFiles\\log4j.xml");
		
		String destfolder=getFolder("video").toString();
		String timestamp=currentDateTime();
		recorder = new ATUTestRecorder(destfolder,"TestVideo_"+timestamp,false);
		//recorder.start();
	}

	@AfterSuite
	public void afterSuite() throws Exception {
		report.endTest(test);
		report.flush();
		String workingDir = System.getProperty("user.dir");
		File htmlFile = new File(workingDir+"\\Report\\TestReport.html");
		Desktop.getDesktop().browse(htmlFile.toURI());
		//MailSetup.SendEmail();
		//recorder.stop();
	}
	
	public String getMethodName(){
		String method=new Exception().getStackTrace()[1].getMethodName();
		return method;
	}

	public  File getScreenshotFolder(){
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy") ;
		String curDate =dateFormat.format(date);
		String dest=System.getProperty("user.dir")+"\\ScreenShots\\";
		//String dest="//192.168.26.32//AutomationProjects//ScreenShots//";		
		File Path = new File(dest+curDate);
		Path.mkdir();
		return Path;	
	}
	
	public  File getFolder(String folderName){
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy") ;
		String curDate =dateFormat.format(date);
		String dest=System.getProperty("user.dir")+"\\"+folderName+"\\";
		//String dest="//192.168.26.32//AutomationProjects//ScreenShots//";		
		File Path = new File(dest+curDate);
		Path.mkdirs();
		return Path;	
	}

	public  String currentDateTime()
	{
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy,HH-mm");
		String formattedDate = sdf.format(date);
		formattedDate.toString();
		return formattedDate;
	}

	public String takeScreenShot(String name) throws Exception
	{
		File path=getScreenshotFolder();
		String time=currentDateTime();
		String dest=path+"//"+name+"_"+time+".png";
		Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(Driver.getWD());
		//Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.).takeScreenshot(Driver.d);
		//Screenshot screenshot = new AShot().takeScreenshot(Driver.d);
		
		//BufferedImage image1 = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
		//ImageIO.write(image1, "PNG", new File(dest));
		
		ImageIO.write(screenshot.getImage(), "PNG", new File(dest));	
		String image= test.addScreenCapture(dest);
		test.log(LogStatus.FAIL, "Testcase Failed", image);
		return dest;
	}


	public void startTest(String testCase_ID,String ClassName){
		int rowNumber=PageActions.xls.getFirstDataRowNum("TestCases", "TCID", testCase_ID);
		String TCDesc=PageActions.xls.getCellData("TestCases", "Descrption", rowNumber);
		test = report.startTest(testCase_ID+": "+TCDesc);
		test.log(LogStatus.INFO,"Scenario: "+ TCDesc);
		test.assignCategory(ClassName);	
		Log.startTest(testCase_ID);
	}

	public void tryBlock(String testCase_ID,String description){
		int rowNumber=PageActions.xls.getFirstDataRowNum("TestCases", "TCID", testCase_ID);
		PageActions.xls.setCellData("TestCases", "Status", rowNumber, "PASS");
		test.log(LogStatus.PASS, description);
		report.endTest(test);
		Log.endTest(testCase_ID);
		
	}

	public void catchBlock(String exception,String testCase_ID) throws Exception{
		System.out.println("catch block1: "+exception+testCase_ID);
		int rowNumber=PageActions.xls.getFirstDataRowNum("TestCases", "TCID", testCase_ID);
		PageActions.xls.setCellData("TestCases", "Status", rowNumber, "FAIL");
		test.log(LogStatus.FAIL, exception);		
		takeScreenShot(testCase_ID);	
		report.endTest(test);	
		Log.info(exception);
		System.out.println("catch block2: "+exception+testCase_ID);
		Log.endTest(testCase_ID);
	}
	
	
	
	public boolean skip_Test(String testCase_ID){
		boolean isSkip=false;
		int rowNumber=PageActions.xls.getFirstDataRowNum("TestCases", "TCID", testCase_ID);
		String runMode=PageActions.xls.getCellData("TestCases", "Run", rowNumber);
		if(runMode.contentEquals("No")|| runMode.isEmpty()){
			isSkip=true;
		}
		else{
			isSkip=false;
		}
		if(isSkip){
			throw new SkipException("Skip this TestCase");
		}
		return isSkip;

	}

}
