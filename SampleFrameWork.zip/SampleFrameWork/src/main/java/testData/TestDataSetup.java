package testData;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;

public class TestDataSetup {
	 

		public final  String excelWorkBook="TestData.xlsx";
		
		public Xls_Reader  finance_xls=null;
		
		
		public final  String col_TestCaseID="TCID";
		public final  String col_UserName="UserName";
		public final  String col_PassWord="Password";
		public final String col_TCDescription="Test Script Name";
			
		public  String UserName;
		public String Password;



		public TestDataSetup(){
			String path=System.getProperty("user.dir")+"//TestDataFiles//"+excelWorkBook;	
			finance_xls = new Xls_Reader(path);	
		}


		@DataProvider
		public  Object[][] loginCredintials(Method method) {

			System.out.println("running"+method.getName());
			String testCaseID=method.getName();
			int strow=finance_xls.getFirstDataRowNum("sheetname", col_TestCaseID, testCaseID);
			int ltrow=finance_xls.getLastDataRowNum("sheetname",col_TestCaseID, testCaseID,strow);

			System.out.println("Start Row"+strow);
			System.out.println("Last Row"+ltrow);

			Object[][] obj =  new Object[(ltrow-strow)+1][2];
			int incr=0;

			for(int i=strow; i<=ltrow;i++){
				obj[incr][0]=finance_xls.getCellData("sheetname", col_UserName, i);
				obj[incr][1]=finance_xls.getCellData("sheetname", col_PassWord, i);
				incr++;
			}

			return obj;


		}
		//My document details page
		@DataProvider
		public  Object[][] loginCredintials1(Method method) {

			System.out.println("running: "+method.getName());
			String testCaseID=method.getName();
			int strow=finance_xls.getFirstDataRowNum("sheetname", col_TestCaseID, testCaseID);
			int ltrow=finance_xls.getLastDataRowNum("sheetname",col_TestCaseID, testCaseID,strow);

			System.out.println("Start Row"+strow);
			System.out.println("Last Row"+ltrow);

			Object[][] obj =  new Object[(ltrow-strow)+1][3];
			int incr=0;

			for(int i=strow; i<=ltrow;i++){
				obj[incr][0]=finance_xls.getCellData("sheetname", col_UserName, i);
				obj[incr][1]=finance_xls.getCellData("sheetname", col_PassWord, i);
				incr++;
			}

			return obj;


		}






		public int getTestCaseRowRumberinExcel(Xls_Reader xls_obj, String sheetName,String MethodName)
		{	
			return xls_obj.getFirstDataRowNum(sheetName, col_TestCaseID, MethodName);
		}


		public void setLoginData(Xls_Reader xls_obj,String sheetName,String method)
		{	
			int row=getTestCaseRowRumberinExcel(xls_obj,sheetName,method);
			UserName=xls_obj.getCellData(sheetName, col_UserName, row);
			Password=xls_obj.getCellData(sheetName, col_PassWord, row);	
		}

		public String getUserName(){
			return UserName;
		}

		public String getPassword(){
			return Password;
		}


		/** To get test case description from Summary sheet.
		 * @param sheetName
		 * @param method
		 */
		public String getTCDescription(Xls_Reader xls_obj,String sheetName,String method){
			int rowNum=getTestCaseRowRumberinExcel(xls_obj,sheetName,method);
			return xls_obj.getCellData(sheetName, col_TCDescription, rowNum);
		}



}
