package webDriver;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class Driver {


	public static WebDriver d;
	public static String downloadFilepath= null;
	public static ExtentTest test;
	public static ExtentReports report;


	public static void open(String Browser,String url) {
		String dir=System.getProperty("user.dir");
		if(Browser.contentEquals("Chrome"))
		{
			String ChromePath = "driver/chromedriver.exe";
			System.setProperty("webdriver.chrome.driver",ChromePath);	
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("useAutomationExtension", false);
			//options.setExperimentalOption("excludeSwitches",Collections.singletonList("enable-automation"));    	
			d = new ChromeDriver(options);
			d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			d.manage().window().maximize();
			d.get(url);
		}
		else if(Browser.contentEquals("Firefox"))  {
			FirefoxProfile profile = new FirefoxProfile();
			DesiredCapabilities capabilities = DesiredCapabilities.firefox();
			downloadFilepath = System.getProperty("user.dir")+"\\Download\\";
			profile.setPreference("browser.download.folderList",2);
			/*prof.setPreference("browser.download.manager.showWhenStarting",false);*/
			profile.setPreference("browser.download.dir",downloadFilepath); 
			//path = [location to save the downloaded files]
			profile.setPreference("browser.helperApps.neverAsk.saveToDisk","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;"
					+ "application/pdf;"
					+ "application/vnd.openxmlformats-officedocument.wordprocessingml.document;"
					+ "text/plain;" + "text/csv;" + "application/vnd.ms-excel;");

			capabilities.setBrowserName("firefox");
			capabilities.setPlatform(Platform.WINDOWS);
			capabilities.setCapability(FirefoxDriver.PROFILE, profile);	
			d=new FirefoxDriver();
			d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			d.manage().window().maximize();
			d.get(url);
		}
		else if(Browser.contentEquals("IE")){
			String driverPath = dir+"\\driver\\IEDriverServer.exe";
			System.setProperty("webdriver.ie.driver", driverPath);
			d = new InternetExplorerDriver();
			d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			d.manage().window().maximize();
			d.get(url);
		}
	}

	public static WebDriver getWD()
	{
		return d;
	}

	public static void sendKey(By obj,String text){		
		WebDriverWait wait = new WebDriverWait(d, 25);
		WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		el.sendKeys(text);
		//d.findElement(obj).sendKeys(text)
	}

	public static void sendKeyandTab(By obj,String text){		
		WebDriverWait wait = new WebDriverWait(getWD(), 25);
		WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		el.sendKeys(text);
		wait(2);
		el.sendKeys(Keys.valueOf(("TAB")));	
		wait(1);
	}

	public static void clear_sendKeys(By obj,String text){		
		WebDriverWait wait = new WebDriverWait(d, 25);
		WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		el.clear();
		el.sendKeys(text);
		//d.findElement(obj).sendKeys(text)
	}

	public static void click(By obj){
		WebDriverWait wait = new WebDriverWait(getWD(), 15);
		WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		el.click();
		//d.findElement(obj).click();
	}

	public static void select(By obj,String text){	
		WebDriverWait wait = new WebDriverWait(getWD(),5);
		WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		/*WebElement element=null;
		element =getWD().findElement(obj);*/
		new Select(el).selectByVisibleText(text);

	}
	public static void selectValue(By obj,String text){	
		WebElement element=null;
		element =getWD().findElement(obj);
		new Select(element).selectByValue(text);
	}

	public static void click(By obj,int time){
		WebDriverWait wait = new WebDriverWait(getWD(), time);
		WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		el.click();
	}

	public static void click_linkText(String text){
		click(By.linkText(text));
	}

	public static void clear(By obj){
		getWD().findElement(obj).clear();
	}
	public static void keyBoard(By obj, String Key){

		getWD().findElement(obj).sendKeys(Keys.valueOf(Key));
	}

	public static String getText(By obj){
		WebDriverWait wait = new WebDriverWait(getWD(), 60);
		WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		return el.getText();
	}

	public static String getText_ExplicitWait(By obj,int time){
		WebDriverWait wait = new WebDriverWait(getWD(), time);
		WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		return el.getText();
	}

	public static void scrollBarHandle(By obj){

		JavascriptExecutor js = (JavascriptExecutor)d;
		WebElement element=d.findElement(obj);
		js.executeScript("arguments[0].scrollIntoView(true);",element);
	}

	public static void wait(int sleeptime){
		try {
			Thread.sleep(sleeptime*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void selectNewDropDown(By obj,String text){
		click(obj);
		wait(2);
		click(By.xpath("//li[contains(text(),'"+text+"')]"));
	}

	public static String getText_withoutwait(By obj){
		//WebDriverWait wait = new WebDriverWait(d, 2);
		//WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		d.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		return d.findElement(obj).getText();
	}

	public static List<WebElement> getWebElementsBytagName(By obj){
		WebElement table = d.findElement(obj);
		List<WebElement> el = table.findElements(By.tagName("tr"));
		return el;	
	}

	public static void jsClick(By obj){

		JavascriptExecutor js = (JavascriptExecutor)getWD();
		WebElement element=getWD().findElement(obj);
		js.executeScript("arguments[0].click();", element);
	}

	public  void jsClick1(By obj){
		JavascriptExecutor js = (JavascriptExecutor)d;
		WebElement element=d.findElement(obj);
		js.executeScript("arguments[0].click();", element);
	}

	public static void jsSendKeys(By obj, String text){
		JavascriptExecutor js = (JavascriptExecutor)d;
		WebElement element=d.findElement(obj);
		js.executeScript("arguments[0].click();", element);	
		js.executeScript("arguments[0].value='"+text+"';", element);

	}

	public  static String getPageTitle(){
		return getWD().getTitle();
	}

	public static boolean isAlertPresent() {
		WebDriverWait wait = new WebDriverWait(getWD(),10);
		try{
			wait.until(ExpectedConditions.alertIsPresent());
			return true;
		}
		catch(Exception e){
			return false;
		}
	}

}
